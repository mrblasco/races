/**
 * 
 */
package banner.tagging;

public enum TagFormat
{
	IO, IOB, IOE, IOBEW;
}