from lxml import etree
from collections import defaultdict
from itertools import izip
import sys
import nltk

from colored_text import ColoredText

skipped = 0
processed = 0
values = []
learning_set = defaultdict(list)
answer = defaultdict(float)


def words_similarity(wordA, wordB):
    if wordA == wordB:
        return 1
    min_len = min(len(wordA), len(wordB))
    if wordA[0].isupper() and wordB[0].isupper() and any(x.islower() for x in wordA[1:]) and any(x.islower() for x in wordB[1:]):
        return 1
    for i in xrange(min_len):
        if wordA[len(wordA) - 1 - i:] != wordB[len(wordB) - 1 - i:]:
            return i / float(min_len)
        if i == 7:
            return 1
    return 0


def compare_samples(sampleA, sampleB):
    res_suff = 0.0
    res_pos = 0.0
    for tagA, tagB in izip(sampleA[1:-2], sampleB[1:-2]):
        res_suff += words_similarity(tagA[0], tagB[0])
        res_pos += int(tagA[1] == tagB[1])

    if res_suff > sampleA[0] - 1e-4:
        return 1

    res = res_suff + res_pos
    res += int(sampleA[-2][1] == sampleB[-2][1])
    res += int(sampleA[-1][1] == sampleB[-1][1])

    return res / (2.0 * sampleA[0] + 2)


def get_sample(pos_tags, first_token, last_token):
    if first_token == last_token and all(ch.isupper() or ch.isdigit() for ch in pos_tags[first_token][0]):
        return []
    last_token += 1

    sample = [last_token - first_token]
    sample += pos_tags[first_token:last_token]
    sample += [("", None) if first_token == 0 else pos_tags[first_token - 1]]
    sample += [("", None) if last_token == len(pos_tags) else pos_tags[last_token]]
    return sample


def add_to_learning_set(sample):
    learning_set[sample[0]].append(sample)


def calc_sample_value(sample):
    z = max(compare_samples(sample, xsample) for xsample in learning_set[sample[0]]) \
        if sample[0] in learning_set else 0
    text = " ".join(tag[0] for tag in sample[1:-2]).lower()
    global answer
    answer[text] = max(answer[text], z)


def check_sample(sample):
    global values
    text = " ".join(tag[0] for tag in sample[1:-2]).lower()
    global answer
    z = answer[text]
    print text, z
    values.append(z)


def map_tokens_to_string(tokens, string):
    it = 0
    ip = 0
    result = []
    try:
        while it < len(tokens):
            if tokens[it][0] == string[ip]:
                result.append((ip, ip + len(tokens[it])))
                ip += len(tokens[it])
                it += 1
            else:
                ip += 1
    except:
        print tokens
        print tokens[it]
        print string
        raise

    return result


def process_passage(element, sample_func):
    text_tag = element.find("text")
    gl_offset = int(element.find("offset").text)
    text = text_tag.text
    text = text.replace("--", "qq")
    nltk_tokens = nltk.word_tokenize(text)
    for i in xrange(len(nltk_tokens)):
        if nltk_tokens[i] in ['``', "''"]:
            nltk_tokens[i] = '"'
    global skipped, processed

    processed += 1
    pos_tags = nltk.pos_tag(nltk_tokens)
    tokens_pos = map_tokens_to_string(nltk_tokens, text)

    for ann in element.findall("annotation"):
        location = ann.find('location')
        offset = -gl_offset + int(location.get('offset'))
        length = int(location.get('length'))
        for i in xrange(len(tokens_pos)):
            if tokens_pos[i][0] <= offset < tokens_pos[i][1]:
                first_token = i
            if tokens_pos[i][0] <= offset + length - 1 < tokens_pos[i][1]:
                last_token = i

        sample = get_sample(pos_tags, first_token, last_token)
        if not sample:
            continue
        sample_func(sample)

    print processed


def process_xml(xml_filename, sample_func):
    for _, element in etree.iterparse(open(xml_filename),
            tag="passage", encoding="utf-8", resolve_entities=False, no_network=True):
        process_passage(element, sample_func)
        element.clear()


def main():
    global processed, skipped
    processed, skipped = 0, 0
    process_xml(sys.argv[1], add_to_learning_set)
    print "Processed: {0}, skipped: {1}".format(processed, skipped)
    for cnt, samples in learning_set.iteritems():
        print "{0:2d} tokens: {1} samples".format(cnt, len(samples))

    processed, skipped = 0, 0
    process_xml(sys.argv[2], calc_sample_value)
    processed, skipped = 0, 0
    process_xml(sys.argv[2], check_sample)

    global values
    values = sorted(values)[::-1]
    print "Quantiles:"
    for q in [0.75, 0.8, 0.825, 0.85, 0.875, 0.9]:
        print q, values[int(len(values) * q)]

if __name__ == "__main__":
    main()
