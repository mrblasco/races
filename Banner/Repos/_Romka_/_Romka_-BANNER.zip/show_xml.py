from lxml import etree
import sys

from colored_text import ColoredText


def print_passage(element):
    text_tag = element.find("text")
    gl_offset = int(element.find("offset").text)
    text = ColoredText(text_tag.text)
    for ann in element.findall("annotation"):
        location = ann.find('location')
        offset = -gl_offset + int(location.get('offset'))
        length = int(location.get('length'))
        text.add_style(offset, offset + length, "yellow")
    text.show()
    raw_input()

def main():
    xml_filename = sys.argv[1]
    for _, element in etree.iterparse(open(xml_filename),
            tag="passage", encoding="utf-8", resolve_entities=False, no_network=True):
        print_passage(element)
        element.clear()

if __name__ == "__main__":
    main()
