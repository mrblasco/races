All xml configuration files contain the string "***PATH***"
as a placeholder to the path for the necessary file on your
local machine. These are usually either corpus files, such 
as those for the BioCreative 2 Gene Mention dataset, or
data files, such as those for the UMLS Metathesaurus.

