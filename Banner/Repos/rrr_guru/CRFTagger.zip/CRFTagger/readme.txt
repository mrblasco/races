Hello, 
	to try solve this problem, I reuse existing code.
Changes I made there are in "CRFTagger.java" file, line 129.
All parameters were chosen experimentally. I'm not familiar with
any "GIT" software, so please be understanding checking my solution.
I try go follow this:

	"you can either compress your folder and attach the zipped file as a reply to this email"

but i received that message:
	
	"<ablasco@fas.harvard.edu>: message size 80119005 exceeds size
limit 15000000 of
    server smtp.fas.harvard.edu[140.247.35.194]"

so i attached only file with change "CRFTagger.zip".

	Best regards
		Robert Sobolewski (rrr_guru)
