from termcolor import colored
import sys


class ColoredText(object):
    def __init__(self, s):
        self.text = s
        self.colors = []

    def add_style(self, start, end, style):
        self.colors.append((start, end, style))

    def show(self, out=sys.stdout):
        actions = [(start, "+" + style) for start, _, style in self.colors] + \
                  [(end, "-" + style) for _, end, style in self.colors]
        actions += [(0, ""), (len(self.text), "")]
        actions.sort()

        styles = []
        res = ""
        try:
            for i in xrange(1, len(actions)):
                prev = actions[i-1][0]
                cur = actions[i][0]
                if prev < cur:
                    ns = sorted(set(styles), key=lambda x: x.count("_"))
                    if len(ns) == 1:
                        if ns[0].startswith("on_"):
                            ns = ["white"] + ns
                    res += colored(self.text[prev:cur], *ns)
                nstyle = actions[i][1]
                if nstyle.startswith("+"):
                    styles.append(nstyle[1:])
                if nstyle.startswith("-"):
                    styles.remove(nstyle[1:])
        except:
            print >>sys.stderr, ns
            raise

        print >>sys.stderr, res
